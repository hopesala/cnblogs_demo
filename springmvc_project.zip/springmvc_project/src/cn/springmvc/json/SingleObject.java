package cn.springmvc.json;

public class SingleObject extends AbstractJsonObject {

	private Object object;

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

}
