package cn.springmvc.service;

import java.util.List;

import cn.springmvc.model.Students;

/**
 */
public interface StudentService {

	
	public List<Students> getAllStudents();
}
