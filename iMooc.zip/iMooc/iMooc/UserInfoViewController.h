//
//  UserInfoViewController.h
//  iMooc
//
//  Created by 曹城华 on 2017/4/30.
//  Copyright © 2017年 曹城华. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KeyValueView.h"

@interface UserInfoViewController : UIViewController

@property (nonatomic, strong)KeyValueView *userNameView;
@property (nonatomic, strong)KeyValueView *userSexView;
@property (nonatomic, strong)KeyValueView *birthdayView;
@property (nonatomic, strong)KeyValueView *emailView;
@property (nonatomic, strong)KeyValueView *phoneView;

@end
