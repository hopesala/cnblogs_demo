//
//  UserInfoViewController.m
//  iMooc
//
//  Created by 曹城华 on 2017/4/30.
//  Copyright © 2017年 曹城华. All rights reserved.
//

#import "UserInfoViewController.h"

#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height



// 遵循的协议，协议里面定义了一些方法 NSURLConnectionDataDelegate -->  <NSURLConnectionDataDelegate>
@interface UserInfoViewController ()
{
    //变量
    //NSMutableData *receiveData_;
}

@end

@implementation UserInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // viewcontroller  下的--->view
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    UILabel *titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, 40, kScreenWidth, 20)];
    [titleLabel setText:@"个人信息展示"];
    titleLabel.backgroundColor=[UIColor clearColor];
    titleLabel.textAlignment=NSTextAlignmentCenter;
    titleLabel.font=[UIFont systemFontOfSize:18];
    
    [self.view addSubview:titleLabel];
    
    
    _userNameView=[[KeyValueView alloc] initWithFrame:CGRectMake(100, 70, kScreenWidth-100*2, 30)];
    _userNameView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:_userNameView];
    
    _userSexView=[[KeyValueView alloc] initWithFrame:CGRectMake(100, 70+30, kScreenWidth-100*2, 30)];
    _userSexView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:_userSexView];
    
    _birthdayView=[[KeyValueView alloc] initWithFrame:CGRectMake(100, 70+30*2, kScreenWidth-100*2, 30)];
    _birthdayView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:_birthdayView];
    
    _emailView=[[KeyValueView alloc] initWithFrame:CGRectMake(100, 70+30*3, kScreenWidth-100*2, 30)];
    _emailView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:_emailView];
    
    _phoneView=[[KeyValueView alloc] initWithFrame:CGRectMake(100, 70+30*4, kScreenWidth-100*2, 30)];
    _phoneView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:_phoneView];
    
    UIButton *getUserInfoButton=[[UIButton alloc] initWithFrame:CGRectMake(100, 70+30*5, kScreenWidth-100*2, 30)];
    getUserInfoButton.backgroundColor=[UIColor redColor];
    [getUserInfoButton setTitle:@"GetRequest" forState:UIControlStateNormal];
    [getUserInfoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    //loadWebRequest: 冒号表示带有入参
    [getUserInfoButton addTarget:self action:@selector(loadWebRequest:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:getUserInfoButton];
    
    
    
    
    
    // Do any additional setup after loading the view.
}

////网络请求的响应结果
//- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
//    NSLog(@"%@",response);
//}
//
////接收网络响应数据， 多次调用
//- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
//    if (receiveData_==nil) {
//        receiveData_=[[NSMutableData alloc] init];
//    }
//    [receiveData_ appendData:data];
////    NSLog(@"%@",data);
//}
//
//- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
//    NSLog(@"网络请求结束");
//    id obj=[NSJSONSerialization JSONObjectWithData:receiveData_ options:0 error:nil];
//    NSLog(@"%@",obj);
//    if ([obj isKindOfClass:[NSDictionary class]]) {
//        id userInfo=[(NSDictionary *)obj objectForKey:@"items"];
//        NSDictionary *item=[(NSArray *)userInfo objectAtIndex:[userInfo count]-1];
//        
//        NSString *userName=[(NSDictionary *)item objectForKey:@"name"];
//        NSLog(@"%@",userName);
//        
//        NSString *userAge=[(NSDictionary *)item objectForKey:@"age"];
//        NSLog(@"%@",userAge);
//        
//        NSString *userId=[(NSDictionary *)item objectForKey:@"id"];
//        NSLog(@"%@",userId);
//        
//        NSString *userMobole=[(NSDictionary *)item objectForKey:@"mobile"];
//        NSLog(@"%@",userMobole);
//        
//        NSString *userSex=[(NSDictionary *)item objectForKey:@"sex"];
//        if ([userSex isKindOfClass:[NSString class]]) {
//            NSLog(@"aaaaa");
//        }
//        if ([userSex isKindOfClass:[NSNumber class]]) {
//            NSLog(@"bbbbb");
//        }
//        
//        //怎么会变成NSNumber类型了
//        if ([userSex intValue]==1) {
//            userSex=@"男";
//        }
//        if ([userSex isEqual:[NSNumber numberWithInt:0]]) {
//            userSex=@"女";
//        }
//        NSLog(@"%@",userSex);
//
//    }
//}

- (void)loadWebRequest:(id)sender {
    NSURL *url=[NSURL URLWithString:@"http://localhost:8080/getAllStudent"];
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
    [connection start];
    
    //resume  名词 简历  动词 【继续】
    NSURLSession *session=[NSURLSession sharedSession];
    NSURLSessionTask *dataTask=[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        id obj=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSLog(@"%@",obj);
        if ([obj isKindOfClass:[NSDictionary class]]) {
            id userInfo=[(NSDictionary *)obj objectForKey:@"items"];
            NSDictionary *item=[(NSArray *)userInfo objectAtIndex:[userInfo count]-1];
            
            NSString *userName=[(NSDictionary *)item objectForKey:@"name"];
            NSLog(@"%@",userName);
            
            NSString *userAge=[(NSDictionary *)item objectForKey:@"age"];
            NSLog(@"%@",userAge);
            
            NSString *userId=[(NSDictionary *)item objectForKey:@"id"];
            NSLog(@"%@",userId);
            
            NSString *userMobole=[(NSDictionary *)item objectForKey:@"mobile"];
            NSLog(@"%@",userMobole);
            
            NSString *userSex=[(NSDictionary *)item objectForKey:@"sex"];
            if ([userSex isKindOfClass:[NSString class]]) {
                NSLog(@"aaaaa");
            }
            if ([userSex isKindOfClass:[NSNumber class]]) {
                NSLog(@"bbbbb");
            }
            
            //怎么会变成NSNumber类型了
            if ([userSex intValue]==1) {
                userSex=@"男";
            }
            if ([userSex isEqual:[NSNumber numberWithInt:0]]) {
                userSex=@"女";
            }
            NSLog(@"%@",userSex);
            
        }
    }];
    [dataTask resume];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
