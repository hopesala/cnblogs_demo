//
//  KeyValueView.h
//  iMooc
//
//  Created by 曹城华 on 2017/4/30.
//  Copyright © 2017年 曹城华. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyValueView : UIView

@property (nonatomic,strong)UILabel *keyLabel;
@property (nonatomic,strong)UILabel *valueLabel;

-(void)setupKey:(NSString *)key value:(NSString *)value;

@end
